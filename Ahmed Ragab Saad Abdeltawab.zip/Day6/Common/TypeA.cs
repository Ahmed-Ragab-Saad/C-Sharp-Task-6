﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6
{
    //--2
    public class TypeA
    {
        private int F;
        internal int G;
        public int H;

        //Access F, G, H
        public void Print()
        {
            Console.WriteLine(F);
            Console.WriteLine(G);
            Console.WriteLine(H);
        }

    }
}
