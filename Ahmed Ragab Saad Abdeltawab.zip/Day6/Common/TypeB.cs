﻿using Day6;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    //--2
    class TypeB : TypeA
    {
        //Access G, H
        public void Print()
        {
            Console.WriteLine(G);
            Console.WriteLine(H);
        }
    }
}
