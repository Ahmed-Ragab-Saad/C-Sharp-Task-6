﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6
{
    struct Point
    {
        public int x, y;

        //--1
        public Point()
        {
            x = y = 0;
        }
        //--1 and 4
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        //--4
        public Point(int x)
        {
            this.x = x;
            y = 0;
        }

        //public override string ToString()
        //{
        //    return $"({x}, {y})";
        //}
        
        //--5
        public override string ToString()
        {
            return $"X: {x}, Y: {y}";
        }

    }
}
