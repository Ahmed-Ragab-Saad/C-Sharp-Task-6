﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6
{
    //--3
    struct Employee
    {
        private int empId;
        private string name;
        public decimal Salary { get; set; }

        public string GetName()
        {
            return name;
        }

        public void SetName(string Name)
        {
            this.name = Name;
        }

        public int EmpId
        {
            get
            {
                return empId;
            }
            set
            {
                empId = value;
            }
        }

    }
}
