﻿using Common;

namespace Day6
{
    class Day6
    {
        //--5
        public static void ChangeClassValue(Employees e)
        {
            e.Salary += 1000;
        }
        public static void ChangeStrucrValue(Point p)
        {
            p.x += 1;
            p.y += 1;
        }
        public static void Main(string[] args)
        {
            #region Problem 1
            ////--1
            //Point p1 = new Point();
            //Console.WriteLine(p1.ToString());
            //Point p2 = new Point(3, 5);
            //Console.WriteLine(p2.ToString());
            ////Why can't a struct inherit from another struct or class in C#?
            ////- They are value types with stack-based memory allocation while inheritance requires reference semantics
            ////- Allowing inheritance would break their predictable and lightweight behavior.
            ////- It prevents potential issues with copying, boxing/unboxing, and runtime behavior.
            ////- Structs are optimized for simplicity and performance and inheritance would add unnecessary complexity. 
            #endregion

            #region Problem 2
            ////--2
            ////Access H
            //TypeA a = new TypeA();
            //Console.WriteLine(a.H);
            ////Access modifiers in C# determine the scope and visibility of class members such as fields,
            ////methods, properties, and nested classes
            ////- private: within the same class
            ////- private protected: within the same class, in subclasses within the same assembly
            ////- protected: within the same class, in subclasses
            ////- internel: within the same assembly
            ////- internal protected : in derived classes, within the same assembly
            ////- public: anywhere 
            #endregion

            #region Problem 3
            ////--3
            //Employee e = new Employee();
            //e.SetName("Ahmed");
            //Console.WriteLine(e.GetName());

            //e.EmpId = 7;
            //Console.WriteLine(e.EmpId);

            //e.Salary = 700000;
            //Console.WriteLine(e.Salary);

            ////Why is encapsulation critical in software design?
            ////- Enhances data security
            ////- Promotes code modularity
            ////- Supports maintainability and flexibility
            ////- Encourages abstraction
            ////- Protects object integrity
            ////- Facilitates reusability
            ////- Simplifies testing
            ////- Enhances code readability 
            #endregion

            #region Problem 4
            ////--4
            //Point p1 = new Point(7);
            //Console.WriteLine(p1.ToString());
            //Point p2 = new Point(7, 3);
            //Console.WriteLine(p2.ToString());
            ////Constructors in structs provide a way to initialize the fields of a struct at the time of instantiation.
            ////While structs automatically get a default constructor that initializes all fields to their default values,
            ////you can also define custom parameterized constructors to initialize structs with specific values. 
            #endregion

            #region Problem 5
            ////--5
            //Point p = new Point(3, 7);
            //Console.WriteLine(p.ToString());
            ////ToString() improve code readability by providing a clear, consistent, and meaningful string representation of objects, simplifying debugging, logging, and maintenance. 
            #endregion

            #region Problem 6
            ////--6
            //Employees e = new Employees();
            //e.Salary = 1000;
            ////Salary will be change
            //ChangeClassValue(e);
            //Console.WriteLine(e.Salary);

            //Point p = new Point(7, 3);
            ////Points x and y will not be change
            //ChangeStrucrValue(p);
            //Console.WriteLine(p.ToString());
            ////Structs (Value Types):
            ////- Stack Allocation: Structs are typically allocated on the stack 
            ////- Copying: When passed by value, structs are copied entirely, and the copies are independent.
            ////Classes (Reference Types):
            ////- Heap Allocation: Classes are allocated on the heap.
            ////- Reference: A class variable holds a reference to the object on the heap, not the actual object itself.
            ////- Copying: When passed by reference, classes only pass the reference (not the entire object), meaning modifications affect the original object. 
            #endregion


        }
    }
}